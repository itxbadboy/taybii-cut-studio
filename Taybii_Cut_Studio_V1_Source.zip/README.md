# Taybii Cut Studio — V1 (native Android)

A real, **offline-first**, single-clip video editor written in Kotlin + Jetpack Compose, using Media3 ExoPlayer for preview and Media3 Transformer for MP4 export. It does **not** load a Blogger site or depend on a server.

## Features in V1

- Android Storage Access Framework import (pick a video without broad file permissions).
- Playback and trimming, with adjustable start and end points.
- Rotate clockwise 90° per tap (0/90/180/270).
- Center-crop to Original, 1:1, 9:16, 4:5, or 16:9.
- Preview effects using ExoPlayer and export using the same Media3 effects.
- H.264 MP4 export. Android's save dialog lets you pick a destination on-device.
- Export progress, cancellation, and failure messages.
- Dark/light theme, Taybii Apple Modern palette: `#F5F5F7`, `#1D1D1F`, `#AAAAAA`, `#007AFF`.
- No ads, network permission, watermark, login, or server upload.

## Known limitations

- V1 edits **one** video at a time; no multi-clip timeline, music layers, captions or transitions yet.
- Crops are centered (not draggable) and depend on correct input rotation metadata.
- Source video decoding and MP4 encoding depend on device codecs. Large, unusual HDR, or unsupported files can fail with an actionable error.
- The app does not currently save editing projects between launches. Output MP4 files are saved wherever you select.
- Export is active while the app is visible. Do not force-stop the app or lock the screen during rendering.
- This source was **not compiled in this environment** (Android SDK and Maven/Gradle repository access are unavailable). The GitHub Actions workflow is provided to build and validate the APK.

## Build the APK from GitHub (Android-only)

**Option A — direct source repository**: if these files are pushed to a GitHub repository's root, `.github/workflows/build-apk.yml` runs on pushes to `main` or from *Actions → Build Taybii Cut Studio APK → Run workflow*. After a successful run, download the artifact named `Taybii-Cut-Studio-V1-debug-APK` from the run; extract `app-debug.apk` and install it on Android.

**Option B — easiest from a phone (ZIP upload)**:

1. On your phone, sign into `github.com` and create a blank repository (e.g. `taybii-cut-studio`) with no added README, if possible.
2. Upload **`Taybii_Cut_Studio_V1_Source.zip`** to the repository root using **Add file → Upload files** in GitHub's desktop-site view. Upload it **as ZIP**, do not extract it.
3. Create a repository file **`.github/workflows/build-from-zip.yml`** using **Add file → Create new file**. Paste the complete contents of the companion **`Taybii_Cut_GitHub_Workflow.txt`** into it and commit to the `main` branch.
4. In **Actions**, select **Build Taybii Cut APK From ZIP**, then choose **Run workflow** (it should also trigger automatically after commit).
5. When the build succeeds, open its run, find **Artifacts**, download **Taybii-Cut-Studio-V1-debug-APK**, unzip it using Android Files, and tap `app-debug.apk` to install.
6. On first install, Android may ask you to permit app installation from your browser/file manager. Only install APKs from your own trusted workflow.

A **debug APK** is installable for testing. For distribution on Google Play, you'll need a signed *release* build, its own upload key, and Play policies compliance.

## Technical setup

- Gradle 8.13, Android Gradle Plugin 8.13.2
- JDK 17, Kotlin 2.2.20, Compose Compiler plugin 2.2.20
- `compileSdk 36`, `minSdk 26`, `targetSdk 35`
- Compose BOM 2025.09.00
- Media3 1.11.1 (ExoPlayer, UI, Common, Effects, Transformer)
- Dependency downloads happen **only at build time** on GitHub Actions. The installed app requires no network connection.

> Source can also be opened in Android Studio on a computer if one becomes available, but **no PC is required** for the GitHub build workflow.

## Privacy

The app has **no `INTERNET` permission**. Imported videos stay on your device. Export destination uses Android's document picker; the app writes output MP4 data to that destination. The project does not include analytics or a backend.
