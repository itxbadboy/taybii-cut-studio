package site.taybii.cutstudio

/**
 * Returns normalized Crop half-extents: (horizontal, vertical).
 * Both values stay in (0, 1], with 1 indicating no clipping on that axis.
 * Pure math, independently testable without any Android dependencies.
 */
internal fun centeredCropHalfExtents(
    width: Int, height: Int, effectiveRotationDegrees: Int, targetAspectRatio: Float
): Pair<Float, Float> {
    require(width > 0 && height > 0 && targetAspectRatio > 0f)
    val rotated = ((effectiveRotationDegrees % 360) + 360) % 360
    val aspect = if (rotated % 180 != 0) height.toFloat() / width else width.toFloat() / height
    return if (aspect > targetAspectRatio) {
        (targetAspectRatio / aspect).coerceIn(0.01f, 1f) to 1f
    } else {
        1f to (aspect / targetAspectRatio).coerceIn(0.01f, 1f)
    }
}
