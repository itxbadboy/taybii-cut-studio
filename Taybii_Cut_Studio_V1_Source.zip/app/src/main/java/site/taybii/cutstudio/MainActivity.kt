package site.taybii.cutstudio

import android.content.Context
import android.database.Cursor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.Effects
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Crop
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.roundToLong

private val Blue = Color(0xFF007AFF)
private val Dark = Color(0xFF1D1D1F)
private val Gray = Color(0xFFAAAAAA)
private val Light = Color(0xFFF5F5F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CutStudioScreen(this) }
    }
}

private data class VideoInfo(
    val name: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sourceRotation: Int
)

private enum class CropMode(val title: String, val ratio: Float?) {
    ORIGINAL("Original", null), SQUARE("1:1", 1f), REEL("9:16", 9f / 16f),
    PORTRAIT("4:5", 4f / 5f), WIDE("16:9", 16f / 9f)
}

/** File metadata is read from the user's chosen SAF URI, without broad storage permissions. */
private fun getVideoInfo(context: Context, uri: Uri): VideoInfo {
    var title = "Selected video"
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) title = cursor.getString(0) ?: title
    }
    val mmr = MediaMetadataRetriever()
    try {
        mmr.setDataSource(context, uri)
        val duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            ?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
        val width = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        val height = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rotation = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        return VideoInfo(title, duration, width, height, rotation)
    } finally { mmr.release() }
}

private fun formatTime(millis: Long): String {
    val seconds = (millis.coerceAtLeast(0L)) / 1000
    return "%02d:%02d".format(Locale.US, seconds / 60, seconds % 60)
}

/** These same effects are applied to preview and the exported file. */
@OptIn(UnstableApi::class)
private fun buildVideoEffects(info: VideoInfo, userRotation: Int, mode: CropMode): List<Effect> {
    val result = mutableListOf<Effect>()
    if (userRotation != 0) {
        result += ScaleAndRotateTransformation.Builder()
            .setRotationDegrees(userRotation.toFloat()).build()
    }
    val targetRatio = mode.ratio
    if (targetRatio != null && info.width > 0 && info.height > 0) {
        val (halfWidth, halfHeight) = centeredCropHalfExtents(
            info.width, info.height, info.sourceRotation + userRotation, targetRatio
        )
        result += Crop(-halfWidth, halfWidth, -halfHeight, halfHeight)
    }
    return result
}

private fun makeTrimmedItem(uri: Uri, startMs: Long, endMs: Long): MediaItem {
    val clipping = MediaItem.ClippingConfiguration.Builder()
        .setStartPositionMs(startMs)
        .setEndPositionMs(endMs)
        .build()
    return MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
}

@OptIn(UnstableApi::class)
@Composable
private fun CutStudioScreen(activity: MainActivity) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var darkTheme by remember { mutableStateOf(true) }
    val foreground = if (darkTheme) Light else Dark
    val secondary = if (darkTheme) Color(0xFF9C9CA4) else Color(0xFF65656D)
    val background = if (darkTheme) Color(0xFF111114) else Light
    val surface = if (darkTheme) Color(0xFF1D1D1F) else Color.White
    val thin = if (darkTheme) Color(0xFF36363B) else Color(0xFFE5E5EA)

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) { onDispose { player.release() } }

    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<VideoInfo?>(null) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var rotation by remember { mutableIntStateOf(0) }
    var cropMode by remember { mutableStateOf(CropMode.ORIGINAL) }
    var revision by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Choose a video to start editing.") }
    var busy by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var transformer by remember { mutableStateOf<Transformer?>(null) }
    var temporary by remember { mutableStateOf<File?>(null) }
    var destination by remember { mutableStateOf<Uri?>(null) }

    fun clearOutput() {
        temporary?.delete()
        temporary = null
        destination = null
        transformer = null
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    fun startExport(target: Uri) {
        val source = videoUri
        val video = info
        if (source == null || video == null || video.durationMs < 700L) {
            status = "Select a playable video first."
            return
        }
        val safeEnd = endMs.coerceAtMost(video.durationMs)
        if (safeEnd - startMs < 500L) {
            status = "Trim selection must be at least half a second."
            return
        }
        player.pause()
        busy = true
        saving = false
        progress = 0
        status = "Exporting video on your phone…"
        destination = target
        val temp = File(context.cacheDir, "cut_${System.nanoTime()}.mp4")
        temporary = temp
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            val edited = EditedMediaItem.Builder(makeTrimmedItem(source, startMs, safeEnd))
                .setEffects(Effects(emptyList(), buildVideoEffects(video, rotation, cropMode)))
                .build()
            val task = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        saving = true
                        status = "Saving MP4 to selected folder…"
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) {
                                    context.contentResolver.openOutputStream(target, "w")?.use { out ->
                                        temp.inputStream().use { input -> input.copyTo(out) }
                                    } ?: error("Cannot write to the selected destination")
                                }
                                status = "Saved! Your edited MP4 is ready in the chosen folder."
                            } catch (error: Exception) {
                                status = "Save failed: ${error.message ?: "unknown error"}"
                                try { context.contentResolver.delete(target, null, null) } catch (_: Exception) {}
                            } finally {
                                busy = false
                                saving = false
                                progress = 100
                                clearOutput()
                            }
                        }
                    }
                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        status = "Export failed: ${exportException.message ?: "Unsupported video format"}"
                        busy = false
                        saving = false
                        try { context.contentResolver.delete(target, null, null) } catch (_: Exception) {}
                        clearOutput()
                    }
                }).build()
            transformer = task
            task.start(edited, temp.absolutePath)
        } catch (error: Exception) {
            status = "Couldn't start export: ${error.message ?: "Unknown error"}"
            busy = false
            try { context.contentResolver.delete(target, null, null) } catch (_: Exception) {}
            clearOutput()
        }
    }

    val openVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !busy) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { /* Some providers grant only temporary access. */ }
            try {
                val metadata = getVideoInfo(context, uri)
                require(metadata.durationMs > 0) { "Video duration not readable" }
                videoUri = uri
                info = metadata
                startMs = 0L
                endMs = metadata.durationMs
                rotation = 0
                cropMode = CropMode.ORIGINAL
                revision++
                status = "Loaded ${metadata.name}. Preview it, then edit and export."
            } catch (error: Exception) {
                status = "Cannot open this video: ${error.message ?: "Invalid file"}"
            }
        }
    }
    val saveVideo = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if (uri != null && !busy) startExport(uri)
        else if (uri == null) status = "Save cancelled. Nothing was exported."
    }

    LaunchedEffect(videoUri, revision) {
        val uri = videoUri
        val video = info
        if (uri != null && video != null) {
            try {
                player.pause()
                player.setVideoEffects(buildVideoEffects(video, rotation, cropMode))
                player.setMediaItem(makeTrimmedItem(uri, startMs, endMs.coerceAtMost(video.durationMs)))
                player.prepare()
            } catch (error: Exception) { status = "Preview error: ${error.message}" }
        }
    }
    LaunchedEffect(busy, transformer) {
        while (busy && transformer != null) {
            if (!saving) {
                try {
                    val holder = ProgressHolder()
                    if (transformer?.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                        progress = holder.progress
                    }
                } catch (_: Exception) {}
            }
            delay(300)
        }
    }

    val colors = if (darkTheme) darkColorScheme(
        primary = Blue, surface = surface, background = background,
        onSurface = foreground, onBackground = foreground
    ) else lightColorScheme(
        primary = Blue, surface = surface, background = background,
        onSurface = foreground, onBackground = foreground
    )
    MaterialTheme(colorScheme = colors) {
        Column(
            modifier = Modifier.fillMaxSize().background(background)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding().statusBarsPadding()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Blue),
                    contentAlignment = Alignment.Center
                ) { Text("▶", color = Color.White, fontSize = 23.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Taybii Cut Studio", color = foreground, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("OFFLINE  •  NATIVE ANDROID", color = secondary, fontSize = 10.sp, letterSpacing = 1.sp)
                }
                OutlinedButton(
                    onClick = { darkTheme = !darkTheme },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = foreground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, thin)
                ) { Text(if (darkTheme) "☀ Light" else "☾ Dark", fontSize = 12.sp) }
            }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(surface).border(1.dp, thin, RoundedCornerShape(20.dp))
                    .padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("01   PREVIEW", color = secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text(if (info == null) "No clip" else formatTime(info!!.durationMs), color = secondary, fontSize = 12.sp)
                }
                Box(
                    Modifier.fillMaxWidth().height(220.dp)
                        .clip(RoundedCornerShape(13.dp)).background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (videoUri == null) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("▶", color = Blue, fontSize = 44.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Your video appears here", color = Gray, fontSize = 13.sp)
                        }
                    } else {
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).also { it.player = player; it.useController = true } },
                            update = { it.player = player },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Button(
                    onClick = { openVideo.launch(arrayOf("video/*")) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) { Text(if (videoUri == null) "+   Import video" else "↻   Replace video", color = Color.White, fontWeight = FontWeight.Bold) }
                if (info != null) {
                    Text(info!!.name, color = foreground, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${info!!.width} × ${info!!.height}  •  ${formatTime(info!!.durationMs)}", color = secondary, fontSize = 11.sp)
                }
            }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(surface).border(1.dp, thin, RoundedCornerShape(20.dp))
                    .padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("02   TRIM VIDEO", color = secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Choose the section to keep", color = foreground, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                val total = info?.durationMs ?: 1L
                Text("Start   ${formatTime(startMs)}", color = secondary, fontSize = 12.sp)
                Slider(
                    value = startMs.toFloat(),
                    onValueChange = { startMs = it.roundToLong().coerceIn(0L, (endMs - 500L).coerceAtLeast(0L)) },
                    onValueChangeFinished = { revision++ },
                    valueRange = 0f..(total - 500L).coerceAtLeast(1L).toFloat(),
                    enabled = info != null && !busy,
                    colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue)
                )
                Text("End     ${formatTime(endMs)}", color = secondary, fontSize = 12.sp)
                Slider(
                    value = endMs.toFloat(),
                    onValueChange = { endMs = it.roundToLong().coerceIn((startMs + 500L).coerceAtMost(total), total) },
                    onValueChangeFinished = { revision++ },
                    valueRange = 0f..total.toFloat().coerceAtLeast(1f),
                    enabled = info != null && !busy,
                    colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Kept duration", color = secondary, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(endMs - startMs), color = Blue, fontWeight = FontWeight.Bold)
                }
                Text("Drag a handle, then release to update preview.", color = secondary, fontSize = 11.sp)
            }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(surface).border(1.dp, thin, RoundedCornerShape(20.dp))
                    .padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("03   ROTATE & CROP", color = secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Rotation", color = foreground, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    OutlinedButton(
                        onClick = { rotation = (rotation + 90) % 360; revision++ },
                        enabled = info != null && !busy,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Blue),
                        border = androidx.compose.foundation.BorderStroke(1.dp, thin)
                    ) { Text("⟳  ${rotation}°") }
                }
                Text("Crop aspect ratio", color = foreground, fontWeight = FontWeight.SemiBold)
                CropMode.entries.chunked(3).forEach { modes ->
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        modes.forEach { mode ->
                            val active = cropMode == mode
                            Button(
                                onClick = { cropMode = mode; revision++ },
                                enabled = info != null && !busy,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (active) Blue else background,
                                    contentColor = if (active) Color.White else foreground
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp),
                                modifier = Modifier.height(38.dp)
                            ) { Text(mode.title, fontSize = 12.sp) }
                        }
                    }
                }
                Text("Crop uses a centered frame. Preview reflects selected effects.", color = secondary, fontSize = 11.sp)
            }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(surface).border(1.dp, thin, RoundedCornerShape(20.dp))
                    .padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("04   EXPORT MP4", color = secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("H.264 video • MP4", color = foreground, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("NO WATERMARK", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                if (busy) {
                    LinearProgressIndicator(
                        progress = { (progress / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(), color = Blue
                    )
                    Text(if (saving) "Saving file…" else "$progress% rendered", color = secondary, fontSize = 12.sp)
                    OutlinedButton(onClick = {
                        transformer?.cancel()
                        destination?.let { try { context.contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                        busy = false
                        saving = false
                        clearOutput()
                        status = "Export cancelled."
                    }, enabled = !saving, modifier = Modifier.fillMaxWidth()) { Text("Cancel export") }
                } else {
                    Button(
                        onClick = { saveVideo.launch("TaybiiCut_${System.currentTimeMillis()}.mp4") },
                        enabled = info != null,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) { Text("Export & save MP4  ↗", color = Color.White, fontWeight = FontWeight.Bold) }
                }
                Text(status, fontSize = 12.sp, color = if (status.contains("failed", true) || status.contains("error", true)) Color(0xFFFF7979) else secondary)
                Text("All editing runs on this phone. No internet, account or upload required.", color = secondary, fontSize = 11.sp)
            }
            Text(
                "TAYBII CUT STUDIO   •   V1.0   •   SINGLE-CLIP EDITOR",
                color = secondary, fontSize = 10.sp,
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            )
        }
    }
}
